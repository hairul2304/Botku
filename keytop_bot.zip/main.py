from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from tempmail import create_temp_mail
from utils import simpan_akun, generate_password

def buat_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(options=options)

def register_keytop(email, password, referral):
    driver = buat_driver()
    driver.get("https://keytop.io")
    time.sleep(5)

    try:
        driver.find_element(By.XPATH, '//button[text()="Sign up"]').click()
        time.sleep(2)
        driver.find_element(By.NAME, "email").send_keys(email)
        driver.find_element(By.NAME, "password").send_keys(password)
        driver.find_element(By.NAME, "referralCode").send_keys(referral)
        driver.find_element(By.XPATH, '//button[text()="Register"]').click()
        time.sleep(5)
        print(f"Akun dibuat: {email}")
    except Exception as e:
        print(f"Error registrasi: {e}")
    finally:
        driver.quit()

    simpan_akun(email, password)

# ===== MAIN =====
referral = "MASUKKAN_REFERRAL_KAMU"  # ganti dengan referral kamu
jumlah = 3  # jumlah akun

for _ in range(jumlah):
    email, _, _ = create_temp_mail()
    password = generate_password()
    register_keytop(email, password, referral)
