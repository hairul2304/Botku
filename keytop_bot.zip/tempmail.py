import requests
import random
import time

def create_temp_mail():
    domain_resp = requests.get("https://api.mail.tm/domains")
    domain = domain_resp.json()['hydra:member'][0]['domain']
    username = f"user{random.randint(10000, 99999)}"
    email = f"{username}@{domain}"
    password = "BotKeytop" + str(random.randint(100, 999))

    session = requests.Session()
    create = session.post("https://api.mail.tm/accounts", json={
        "address": email,
        "password": password
    })

    if create.status_code != 201:
        raise Exception("Gagal buat akun mail.tm")

    token_req = session.post("https://api.mail.tm/token", json={
        "address": email,
        "password": password
    })

    token = token_req.json()["token"]
    return email, password, token
