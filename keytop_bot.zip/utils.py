import json
import random
import string

def simpan_akun(email, password):
    akun = {"email": email, "password": password}
    with open("akun.json", "a") as f:
        json.dump(akun, f)
        f.write("\n")

def load_akun():
    with open("akun.json") as f:
        return [json.loads(line) for line in f.readlines()]

def generate_password(length=10):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))
