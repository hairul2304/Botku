from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from utils import load_akun
import schedule

def buat_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(options=options)

def login_and_mine(email, password):
    driver = buat_driver()
    try:
        driver.get("https://www.key.top/#/pages/login/index")
        time.sleep(4)

        driver.find_element(By.NAME, "email").send_keys(email)
        driver.find_element(By.NAME, "password").send_keys(password)
        driver.find_element(By.XPATH, '//button[text()="Login"]').click()
        time.sleep(5)

        try:
            mining_button = driver.find_element(By.XPATH, '//button[contains(text(),"Start Mining")]')
            mining_button.click()
            print(f"[✔] Mining dimulai: {email}")
        except:
            print(f"[✓] Mining sudah aktif atau tombol tidak muncul: {email}")
    except Exception as e:
        print(f"[!] Gagal mining: {email} - {e}")
    finally:
        driver.quit()

def jalankan_semua():
    akun_list = load_akun()
    for akun in akun_list:
        login_and_mine(akun["email"], akun["password"])

# Jadwal setiap 24 jam
schedule.every(24).hours.do(jalankan_semua)

print("⏳ Bot mining aktif... Menunggu siklus 24 jam pertama")
jalankan_semua()  # Eksekusi pertama kali langsung

while True:
    schedule.run_pending()
    time.sleep(60)
